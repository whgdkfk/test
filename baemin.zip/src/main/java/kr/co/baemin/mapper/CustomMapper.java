package kr.co.baemin.mapper;

import kr.co.baemin.vo.MtmVo;

public interface CustomMapper {
	public void mtm_ok(MtmVo mvo);
}

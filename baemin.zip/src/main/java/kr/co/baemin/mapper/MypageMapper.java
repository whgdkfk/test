package kr.co.baemin.mapper;

import java.util.ArrayList;

import kr.co.baemin.vo.CartVo;
import kr.co.baemin.vo.WishVo;

public interface MypageMapper {
	public ArrayList<WishVo> wishview(String userid);
	public void wishdel(String id);
	public void cartadd(String fcode, String menu, String su, String userid, String price, String baeprice);
	public int cart_check(String menu, String userid);
	public ArrayList<CartVo> cartview(String userid);
	public void cartup(String su, String price, String menu, String userid);
	public void cartdel(String id);
	public void cartsu(int su, int price, String menu, String userid);
}

package kr.co.baemin.service;

import kr.co.baemin.vo.MtmVo;

public interface CustomService {
	public String mtm_ok(MtmVo mvo);
}

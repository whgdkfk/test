package kr.co.baemin.service;

import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import kr.co.baemin.mapper.MypageMapper;
import kr.co.baemin.vo.CartVo;
import kr.co.baemin.vo.FoodVo;

@Service
@Qualifier("ms")
public class MypageServiceImpl implements MypageService{
	@Autowired
	private MypageMapper mapper;

	@Override
	public String wishview(HttpSession session, Model model) {
		
		if(session.getAttribute("userid") == null) {
			return "redirect:/login/login";
		}else {
			String userid = session.getAttribute("userid").toString();
			model.addAttribute("wlist", mapper.wishview(userid));
			return "/mybaemin/wishview";
		}
	}

	@Override
	public String wishdel(HttpServletRequest request) {
		String id = request.getParameter("id");
		mapper.wishdel(id);
		return "redirect:/mybaemin/wishview";
	}

	@Override
	public String cartadd(HttpServletRequest request, HttpSession session, PrintWriter out) {
		String fcode = request.getParameter("fcode");	
		String menu = request.getParameter("menu");
		String su = request.getParameter("su");
	    String price = request.getParameter("price");
	    String baeprice = request.getParameter("baeprice");
	    
		if(session.getAttribute("userid") != null) {
			String userid = session.getAttribute("userid").toString();
			try {
				
				int cnt = mapper.cart_check(menu, userid);
				if(cnt == 1) {
					mapper.cartup(su, price, menu, userid);
				}else {
					mapper.cartadd(fcode, menu, su, userid, price, baeprice);
					out.print("0");
				}
				
			}catch(Exception e) {
				out.print("1");
			}
		}
		return "redirect:/food/fcontent?fcode=${ fvo.fcode }";
	}
	
	@Override
	public String cartview(HttpSession session, Model model) {
		if(session.getAttribute("userid") == null) {
			return "redirect:/login/login";
		}else {
			String userid = session.getAttribute("userid").toString();
			ArrayList<CartVo> clist = mapper.cartview(userid);
			model.addAttribute("clist", clist);
			
			// 메뉴가격, 배달팁 
			String proprice = "";
			String probae = "";
			for(int i=0; i<clist.size(); i++) {
				proprice = proprice + clist.get(i).getPrice()+",";
				probae = probae + clist.get(i).getBaeprice() + ",";
			}
			
			model.addAttribute("proprice", proprice);
			model.addAttribute("probae", probae);
			
			return "/mybaemin/cartview";
		}
	}
}

package kr.co.baemin.service;

import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import kr.co.baemin.mapper.MypageMapper;
import kr.co.baemin.vo.CartVo;

@Service
@Qualifier("ms")
public class MypageServiceImpl implements MypageService{
	@Autowired
	private MypageMapper mapper;

	@Override
	public String wishview(HttpSession session, Model model) {
		
		if(session.getAttribute("userid") == null) {
			return "redirect:/login/login";
		}else {
			String userid = session.getAttribute("userid").toString();
			model.addAttribute("wlist", mapper.wishview(userid));
			return "/mybaemin/wishview";
		}
	}

	@Override
	public String wishdel(HttpServletRequest request) {
		String id = request.getParameter("id");
		mapper.wishdel(id);
		return "redirect:/mybaemin/wishview";
	}

	@Override
	public String cartadd(HttpServletRequest request, HttpSession session, PrintWriter out) {
		String fcode = request.getParameter("fcode");
		String m1_su = request.getParameter("m1_su");
		
		if(session.getAttribute("userid") != null) {
			String userid = session.getAttribute("userid").toString();
			try {
				int cnt = mapper.cart_check(fcode, userid);
				// System.out.println(" msi"+cnt);
				if(cnt == 1) {
					
				}else {
					// System.out.println(fcode+" "+m1_su+" "+userid);
					mapper.cartadd(fcode, m1_su, userid);
				}
				out.print("0");
			}catch(Exception e) {
				out.print("1");
			}
		}
		return "redirect:/food/fcontent?fcode=${ fvo.fcode }";
	}

	@Override
	public String cartview(HttpSession session, Model model) {
		if(session.getAttribute("userid") == null) {
			return "redirect:/login/login";
		}else {
			String userid = session.getAttribute("userid").toString();
			ArrayList<CartVo> clist = mapper.cartview(userid);
			model.addAttribute("clist", clist);
			
			return "/mybaemin/cartview";
		}
	}
}

package kr.co.baemin.service;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

public interface MypageService {
	public String wishview(HttpSession session, Model model);
	public String wishdel(HttpServletRequest request);
	public void cartadd(HttpServletRequest request, HttpSession session, PrintWriter out);
	public String cartview(HttpSession session, Model model);
	public String cartstate(HttpServletRequest request, PrintWriter out, HttpSession session);
	public String cartdel(HttpServletRequest request);
	public void cartsu(HttpServletRequest request, PrintWriter out, HttpSession session);
	public String jumunview(HttpSession session, Model model);
    public String chgstate(HttpServletRequest request);
    public String jumundetail(HttpSession session, Model model, HttpServletRequest request);
    public String jumundel(HttpServletRequest request);
}

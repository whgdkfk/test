package kr.co.baemin.controller;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.co.baemin.service.MypageService;

@Controller
public class MypageController {
	@Autowired
	@Qualifier("ms")
	private MypageService service;
	
	@RequestMapping("/mybaemin/wishview")
	public String wishview(HttpSession session, Model model) {
		return service.wishview(session, model);
	}
	
	@RequestMapping("/mybaemin/wishdel")
	public String wishdel(HttpServletRequest request) {
		return service.wishdel(request);
	}
	
	@RequestMapping("/excludes/cartadd")
	public String cardadd(HttpServletRequest request, HttpSession session, PrintWriter out) {
		return service.cartadd(request, session, out);
	}
	
	@RequestMapping("/mybaemin/cartview")
	public String cartview(HttpSession session, Model model) {
		return service.cartview(session, model);
	}
	
	@RequestMapping("/mybaemin/cartstate")
	public String cartstate(HttpServletRequest request, PrintWriter out, HttpSession session) {
		return service.cartstate(request, out, session);
	}
	
	@RequestMapping("/mybaemin/cartdel")
	public String cartdel(HttpServletRequest request) {
		return service.cartdel(request);
	}
	
	// 장바구니 수량 변경 후 새로고침 했을 때도 변경된 수량으로 표시
	@RequestMapping("/mybaemin/cartsu")
	public void cartsu(HttpServletRequest request, PrintWriter out, HttpSession session) {
		service.cartsu(request, out, session);
	}
	
	@RequestMapping("/mybaemin/jumunview")
	public String jumunview(HttpSession session, Model model) {
		return service.jumunview(session, model);
	}
	
	@RequestMapping("/mybaemin/chgstate")
	public String chgstate(HttpServletRequest request) {
		return service.chgstate(request);
	}
}

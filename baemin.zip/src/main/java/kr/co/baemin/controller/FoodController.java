package kr.co.baemin.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.co.baemin.service.FoodService;

@Controller
public class FoodController {
	@Autowired
	@Qualifier("fs")
	private FoodService service;
	
	@RequestMapping("/food/food")
	public String food(Model model) {
		return service.food(model);
	}
	
	@RequestMapping("/food/getcode")
	public void getCode(HttpServletRequest request, PrintWriter out) {
		service.getCode(request, out);
	}
	
	@RequestMapping("/food/food_ok")
	public String food_ok(HttpServletRequest request) throws IOException {
		return service.food_ok(request);
	}
	
	@RequestMapping("/food/flist")
	public String flist(HttpServletRequest request, Model model) {
		return service.flist(request, model);
	}
	
	@RequestMapping("/food/fcontent")
	public String fcontent(HttpServletRequest request, Model model, HttpSession session) {
		return service.fcontent(request, model, session);
	}
	
	@RequestMapping("/food/wish_add")
	public void wish_add(HttpSession session, HttpServletRequest request,
			PrintWriter out) {
		service.wish_add(request, session, out);
	}

	@RequestMapping("/food/menuall")
	public String menuall(HttpServletRequest request, Model model) {
		return service.menuall(request, model);
	}
	
	@RequestMapping("/food/menuone")
	public String menuone(HttpServletRequest request, Model model) {
		return service.menuone(request, model);
	}
	
	@RequestMapping("/food/franchise")
	public String franchise(HttpServletRequest request, Model model) {
		return service.franchise(request, model);
	}
	
	@RequestMapping("/food/goodtaste")
	public String goodtaste(HttpServletRequest request, Model model) {
		return service.goodtaste(request, model);
	}
	
	@RequestMapping("/excludes/menu_put")
	public String menu_put(HttpServletRequest request, Model model) {
		return service.menu_put(request, model);
	}
	
	@RequestMapping("/excludes/menu_put2")
	public String menu_put2(HttpServletRequest request, Model model) {
		return service.menu_put2(request, model);
	}
	
	@RequestMapping("/excludes/menu_put3")
	public String menu_put3(HttpServletRequest request, Model model) {
		return service.menu_put3(request, model);
	}
	
	@RequestMapping("/excludes/menu_put4")
	public String menu_put4(HttpServletRequest request, Model model) {
		return service.menu_put4(request, model);
	}
	
	@RequestMapping("/excludes/menu_put5")
	public String menu_put5(HttpServletRequest request, Model model) {
		return service.menu_put5(request, model);
	}
	
	@RequestMapping("/food/cartAllDel")
	public void cartAllDel(PrintWriter out)
	{
		service.cartAllDel(out);
	}
}

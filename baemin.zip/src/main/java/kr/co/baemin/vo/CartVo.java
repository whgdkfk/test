package kr.co.baemin.vo;

public class CartVo {
	public int id,m1_su;
	public String fcode,userid,writeday;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getM1_su() {
		return m1_su;
	}
	public void setM1_su(int m1_su) {
		this.m1_su = m1_su;
	}
	public String getFcode() {
		return fcode;
	}
	public void setFcode(String fcode) {
		this.fcode = fcode;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getWriteday() {
		return writeday;
	}
	public void setWriteday(String writeday) {
		this.writeday = writeday;
	}
}

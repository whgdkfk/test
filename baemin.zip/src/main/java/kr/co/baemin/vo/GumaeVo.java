package kr.co.baemin.vo;

public class GumaeVo {
	
	private int id,bae_id,juk,cprice,pay,bank,baeminpay,card,gigan,tong,gibonpay,state,state2,hugi;
	private int su,baeprice;
	private String userid,fcode,writeday,jumuncode,content;
	
	public int getBaeprice() {
		return baeprice;
	}
	public void setBaeprice(int baeprice) {
		this.baeprice = baeprice;
	}
	public int getSu() {
		return su;
	}
	public void setSu(int su) {
		this.su = su;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	String su2,privateprice,menu;
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public String getSu2() {
		return su2;
	}
	public void setSu2(String su2) {
		this.su2 = su2;
	}
	public String getPrivateprice() {
		return privateprice;
	}
	public void setPrivateprice(String privateprice) {
		this.privateprice = privateprice;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getBae_id() {
		return bae_id;
	}
	public void setBae_id(int bae_id) {
		this.bae_id = bae_id;
	}

	public int getJuk() {
		return juk;
	}
	public void setJuk(int juk) {
		this.juk = juk;
	}
	public int getCprice() {
		return cprice;
	}
	public void setCprice(int cprice) {
		this.cprice = cprice;
	}
	public int getPay() {
		return pay;
	}
	public void setPay(int pay) {
		this.pay = pay;
	}
	public int getBank() {
		return bank;
	}
	public void setBank(int bank) {
		this.bank = bank;
	}
	public int getBaeminpay() {
		return baeminpay;
	}
	public void setBaeminpay(int baeminpay) {
		this.baeminpay = baeminpay;
	}
	public int getCard() {
		return card;
	}
	public void setCard(int card) {
		this.card = card;
	}
	public int getGigan() {
		return gigan;
	}
	public void setGigan(int gigan) {
		this.gigan = gigan;
	}
	public int getTong() {
		return tong;
	}
	public void setTong(int tong) {
		this.tong = tong;
	}
	public int getGibonpay() {
		return gibonpay;
	}
	public void setGibonpay(int gibonpay) {
		this.gibonpay = gibonpay;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public int getHugi() {
		return hugi;
	}
	public void setHugi(int hugi) {
		this.hugi = hugi;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getFcode() {
		return fcode;
	}
	public void setFcode(String fcode) {
		this.fcode = fcode;
	}
	public String getWriteday() {
		return writeday;
	}
	public void setWriteday(String writeday) {
		this.writeday = writeday;
	}
	public String getJumuncode() {
		return jumuncode;
	}
	public void setJumuncode(String jumuncode) {
		this.jumuncode = jumuncode;
	}

}

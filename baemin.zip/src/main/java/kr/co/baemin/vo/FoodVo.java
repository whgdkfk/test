package kr.co.baemin.vo;

public class FoodVo {
	private int id,baeprice,minorder,recent_orders,total_orders,wish,star,state,fran;
	private int m1_su,m2_su,m3_su,m4_su,m5_su;
	private String fcode,fimg,shop,baetime,juso,shop_sogae,hours,holiday,
	phone,area,boss,regi_number,benefit,boss_gongji,boss_one,writeday;
	private String m1,m1_img,m1_ex;
	private String m2,m2_img,m2_ex;
	private String m3,m3_img,m3_ex;
	private String m4,m4_img,m4_ex;
	private String m5,m5_img,m5_ex;
	private int m1_price,m2_price,m3_price,m4_price,m5_price;
	
	private String keyword;
	
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public int getM1_su() {
		return m1_su;
	}
	public void setM1_su(int m1_su) {
		this.m1_su = m1_su;
	}
	public int getM2_su() {
		return m2_su;
	}
	public void setM2_su(int m2_su) {
		this.m2_su = m2_su;
	}
	public int getM3_su() {
		return m3_su;
	}
	public void setM3_su(int m3_su) {
		this.m3_su = m3_su;
	}
	public int getM4_su() {
		return m4_su;
	}
	public void setM4_su(int m4_su) {
		this.m4_su = m4_su;
	}
	public int getM5_su() {
		return m5_su;
	}
	public void setM5_su(int m5_su) {
		this.m5_su = m5_su;
	}
	public int getFran() {
		return fran;
	}
	public void setFran(int fran) {
		this.fran = fran;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getBaeprice() {
		return baeprice;
	}
	public void setBaeprice(int baeprice) {
		this.baeprice = baeprice;
	}
	public int getMinorder() {
		return minorder;
	}
	public void setMinorder(int minorder) {
		this.minorder = minorder;
	}
	public int getRecent_orders() {
		return recent_orders;
	}
	public void setRecent_orders(int recent_orders) {
		this.recent_orders = recent_orders;
	}
	public int getTotal_orders() {
		return total_orders;
	}
	public void setTotal_orders(int total_orders) {
		this.total_orders = total_orders;
	}
	public int getWish() {
		return wish;
	}
	public void setWish(int wish) {
		this.wish = wish;
	}
	public int getStar() {
		return star;
	}
	public void setStar(int star) {
		this.star = star;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getFcode() {
		return fcode;
	}
	public void setFcode(String fcode) {
		this.fcode = fcode;
	}
	public String getFimg() {
		return fimg;
	}
	public void setFimg(String fimg) {
		this.fimg = fimg;
	}
	public String getShop() {
		return shop;
	}
	public void setShop(String shop) {
		this.shop = shop;
	}
	public String getBaetime() {
		return baetime;
	}
	public void setBaetime(String baetime) {
		this.baetime = baetime;
	}
	public String getJuso() {
		return juso;
	}
	public void setJuso(String juso) {
		this.juso = juso;
	}
	public String getShop_sogae() {
		return shop_sogae;
	}
	public void setShop_sogae(String shop_sogae) {
		this.shop_sogae = shop_sogae;
	}
	public String getHours() {
		return hours;
	}
	public void setHours(String hours) {
		this.hours = hours;
	}
	public String getHoliday() {
		return holiday;
	}
	public void setHoliday(String holiday) {
		this.holiday = holiday;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getBoss() {
		return boss;
	}
	public void setBoss(String boss) {
		this.boss = boss;
	}
	public String getRegi_number() {
		return regi_number;
	}
	public void setRegi_number(String regi_number) {
		this.regi_number = regi_number;
	}
	public String getBenefit() {
		return benefit;
	}
	public void setBenefit(String benefit) {
		this.benefit = benefit;
	}
	public String getBoss_gongji() {
		return boss_gongji;
	}
	public void setBoss_gongji(String boss_gongji) {
		this.boss_gongji = boss_gongji;
	}
	public String getBoss_one() {
		return boss_one;
	}
	public void setBoss_one(String boss_one) {
		this.boss_one = boss_one;
	}
	public String getWriteday() {
		return writeday;
	}
	public void setWriteday(String writeday) {
		this.writeday = writeday;
	}
	public String getM1() {
		return m1;
	}
	public void setM1(String m1) {
		this.m1 = m1;
	}
	public String getM1_img() {
		return m1_img;
	}
	public void setM1_img(String m1_img) {
		this.m1_img = m1_img;
	}
	public String getM1_ex() {
		return m1_ex;
	}
	public void setM1_ex(String m1_ex) {
		this.m1_ex = m1_ex;
	}
	public String getM2() {
		return m2;
	}
	public void setM2(String m2) {
		this.m2 = m2;
	}
	public String getM2_img() {
		return m2_img;
	}
	public void setM2_img(String m2_img) {
		this.m2_img = m2_img;
	}
	public String getM2_ex() {
		return m2_ex;
	}
	public void setM2_ex(String m2_ex) {
		this.m2_ex = m2_ex;
	}
	public String getM3() {
		return m3;
	}
	public void setM3(String m3) {
		this.m3 = m3;
	}
	public String getM3_img() {
		return m3_img;
	}
	public void setM3_img(String m3_img) {
		this.m3_img = m3_img;
	}
	public String getM3_ex() {
		return m3_ex;
	}
	public void setM3_ex(String m3_ex) {
		this.m3_ex = m3_ex;
	}
	public String getM4() {
		return m4;
	}
	public void setM4(String m4) {
		this.m4 = m4;
	}
	public String getM4_img() {
		return m4_img;
	}
	public void setM4_img(String m4_img) {
		this.m4_img = m4_img;
	}
	public String getM4_ex() {
		return m4_ex;
	}
	public void setM4_ex(String m4_ex) {
		this.m4_ex = m4_ex;
	}
	public String getM5() {
		return m5;
	}
	public void setM5(String m5) {
		this.m5 = m5;
	}
	public String getM5_img() {
		return m5_img;
	}
	public void setM5_img(String m5_img) {
		this.m5_img = m5_img;
	}
	public String getM5_ex() {
		return m5_ex;
	}
	public void setM5_ex(String m5_ex) {
		this.m5_ex = m5_ex;
	}
	public int getM1_price() {
		return m1_price;
	}
	public void setM1_price(int m1_price) {
		this.m1_price = m1_price;
	}
	public int getM2_price() {
		return m2_price;
	}
	public void setM2_price(int m2_price) {
		this.m2_price = m2_price;
	}
	public int getM3_price() {
		return m3_price;
	}
	public void setM3_price(int m3_price) {
		this.m3_price = m3_price;
	}
	public int getM4_price() {
		return m4_price;
	}
	public void setM4_price(int m4_price) {
		this.m4_price = m4_price;
	}
	public int getM5_price() {
		return m5_price;
	}
	public void setM5_price(int m5_price) {
		this.m5_price = m5_price;
	}
}

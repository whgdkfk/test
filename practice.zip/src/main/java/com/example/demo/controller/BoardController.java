package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.service.BoardService;
import com.example.demo.vo.BoardVo;

@Controller
public class BoardController {
	@Autowired
	@Qualifier("bs")
	private BoardService service;
	
	@RequestMapping("/")
	public String home() {
		return "redirect:/list";
	}
	
	@RequestMapping("/list")
	public String list(Model model, HttpServletRequest request) {
		return service.list(model, request);
	}
	
	@RequestMapping("/readnum")
	public String content(HttpServletRequest request) {
		return service.readnum(request);
	}
	
	@RequestMapping("/content")
	public String content(Model model, HttpServletRequest request) {
		return service.content(model, request);
	}
	
	@RequestMapping("/delete")
	public String delete(BoardVo bvo) {
		return service.delete(bvo);
	}
	
	@RequestMapping("/update")
	public String update(Model model, BoardVo bvo) {
		return service.update(model, bvo);
	}
	
	@RequestMapping("/update_ok")
	public String update_ok(BoardVo bvo) {
		return service.update_ok(bvo);
	}
}

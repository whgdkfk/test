package com.example.demo.mapper;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.demo.vo.BoardVo;

@Mapper
public interface BoardMapper {
	public ArrayList<BoardVo> list(@Param("index") int index);
	public int getChong();
	public void readnum(String id);
	public BoardVo content(String id);
	public int isPwd(int id, String pwd);
	public void delete(int id);
	public void update_ok(BoardVo bvo);
}

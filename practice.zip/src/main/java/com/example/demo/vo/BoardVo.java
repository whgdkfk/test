package com.example.demo.vo;

import lombok.Data;

@Data
public class BoardVo {
	private int id,readnum,bimil,page,chk;
	private String title,name,pwd,content,writeday;
}

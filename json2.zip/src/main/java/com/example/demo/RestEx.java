package com.example.demo;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestEx {
	@Autowired
	private BoardMapper mapper;
	
	@RequestMapping("/getList2")
	public ArrayList<BoardVo> getList2(HttpServletRequest request){
		int index = Integer.parseInt(request.getParameter("index"));
		return mapper.getList2(index);
	}
	
	@RequestMapping("/getList22")
	public ArrayList<BoardVo> getList22(HttpServletRequest request){
		int index = Integer.parseInt(request.getParameter("index"));
		return mapper.getList22(index);
	}
}

package com.example.demo;

import lombok.Data;

@Data
public class BoardVo {
	private int id,readnum,bimil;
	private String title,name,pwd,content,writeday;
}

package com.example.demo;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardMapper {
	public ArrayList<BoardVo> getList();
	public ArrayList<BoardVo> getList2(int index);
	public ArrayList<BoardVo> getList22(int index);
}

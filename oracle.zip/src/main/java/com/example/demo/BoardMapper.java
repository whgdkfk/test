package com.example.demo;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.BoardVo;

@Mapper
public interface BoardMapper {
	public void write_ok(BoardVo bvo);
	public ArrayList<BoardVo> list(int page);
	public int getChong();
	public void readnum(String id);
	public BoardVo content(String id);
	public void delete(String id);
	public void update_ok(BoardVo bvo);
}

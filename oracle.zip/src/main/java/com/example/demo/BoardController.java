package com.example.demo;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.BoardVo;

@Controller
public class BoardController {
	@Autowired
	private BoardMapper mapper;
	
	@RequestMapping("/")
	public String home() {
		return "/list";
	}
	
	@RequestMapping("/write")
	public String write() {
		return "/write";
	}
	
	@RequestMapping("/write_ok")
	public String write_ok(BoardVo bvo) {
		for(int i=1; i<=888; i++) {
			bvo.setTitle("test"+i);
			mapper.write_ok(bvo);
		}
		return "redirect:/list";
	}
	
	@RequestMapping("/list")
	public String list(Model model, HttpServletRequest request) {
		// 페이지의 시작인덱스, pstart,pend,chong
		int page;
		if (request.getParameter("page") == null)
			page = 1;
		else
			page = Integer.parseInt(request.getParameter("page"));

		int pstart = page / 10;
		if (page % 10 == 0)
			pstart--;
		pstart = pstart * 10 + 1;

		int pend = pstart + 9;

		int chong = mapper.getChong();

		if (pend > chong)
			pend = chong;

		model.addAttribute("pstart", pstart);
		model.addAttribute("pend", pend);
		model.addAttribute("page", page);
		model.addAttribute("chong", chong);
		ArrayList<BoardVo> list = mapper.list(page);

		model.addAttribute("list", list);
		return "/list";
	}
	
	@RequestMapping("/readnum")
	public String readnum(HttpServletRequest request) {
		String id = request.getParameter("id");
		mapper.readnum(id);
		return "redirect:/content?id="+id;
	}
	
	@RequestMapping("/content")
	public String content(Model model, HttpServletRequest request) {
		String id = request.getParameter("id");
		model.addAttribute("bvo", mapper.content(id));
		return "/content";
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request) {
		String id = request.getParameter("id");
		mapper.delete(id);
		return "redirect:/list";
	}
	
	@RequestMapping("/update")
	public String update(Model model, HttpServletRequest request) {
		String id = request.getParameter("id");
		model.addAttribute("bvo", mapper.content(id));
		return "/update";
	}
	
	@RequestMapping("/update_ok")
	public String update_ok(BoardVo bvo) {
		mapper.update_ok(bvo);
		return "redirect:/content?id="+bvo.getId();
	}
}

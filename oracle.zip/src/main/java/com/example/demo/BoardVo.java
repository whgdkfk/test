package com.example.demo;

import lombok.Data;

@Data
public class BoardVo {
	private int id,readnum;
	private String title,name,pwd,content,writeday;
}

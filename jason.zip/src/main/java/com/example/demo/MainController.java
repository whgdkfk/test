package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MainController {
	@RequestMapping("/")
	public String home() {
		return "/home";
	}
	
	@RequestMapping("/json1")
	public String json1() {
		return "/json1";
	}
	
	@RequestMapping("/json2")
	public String json2() {
		return "/json2";
	}
	
	@RequestMapping("/json3")
	public String json3() {
		return "/json3";
	}
	
	@RequestMapping("/json4")
	public @ResponseBody int json4() {
		return 100;
	}
}

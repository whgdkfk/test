package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@ResponseBody
public class Test2Controller {
	@RequestMapping("/test2")
	public String test2() {
		return "<b>감사합니다</b>";
	}
}

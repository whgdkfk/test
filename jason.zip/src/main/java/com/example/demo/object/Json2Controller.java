package com.example.demo.object;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class Json2Controller {
	@Autowired
	private Member2Mapper mapper;
	
	@RequestMapping("/object/jsonex1")
	public String jsonex1() {
		return "/object/jsonex1";
	}
	
	@RequestMapping("/object/getMember")
	public @ResponseBody Member2Vo getMember() {
		Member2Vo mvo = mapper.getMember();
		return mvo;
	}
	
	@RequestMapping("/object/getAllMember")
	public @ResponseBody ArrayList<Member2Vo> getAllMember() {
		ArrayList<Member2Vo> list = mapper.getAllMember();
		return list;
	}
}

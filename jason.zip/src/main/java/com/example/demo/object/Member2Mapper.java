package com.example.demo.object;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface Member2Mapper {
	@Select("select * from member where id=4")
	public Member2Vo getMember();
	
	@Select("select * from member")
	public ArrayList<Member2Vo> getAllMember();
}

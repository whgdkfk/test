package com.example.demo.object;

import lombok.Data;

@Data
public class Member2Vo {
	private String userid,name,phone;
}

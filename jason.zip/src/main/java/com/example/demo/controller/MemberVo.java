package com.example.demo.controller;

import lombok.Data;

@Data
public class MemberVo {
	private String userid,name,phone;
}

package com.example.demo.controller;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class JsonController {
	@RequestMapping("/jstest/jstest1")
	public String jstest1() {
		return "/jstest/jstest1";
	}
	
	@RequestMapping("/jstest/getMember")
	public void getMember(HttpServletResponse response, PrintWriter out) throws Exception {
		// response.getWriter().print("홍길동");
		out.print("batman");
	}
	
	@RequestMapping("/jstest/getMember2")
	public @ResponseBody String getMember2() {
		return "honggildong";
	}
	
	// JSON형식으로 클라이언트에 전달하기
	@RequestMapping("/jstest/jstest2")
	public String jstest2() {
		return "/jstest/jstest2";
	}
	
	@RequestMapping("/jstest/getJsonMember")
	public @ResponseBody String getJsonMember() {
		// {"변수명":"값", "변수명":"값", "변수명":"값"}
		// String member = " \"안녕\" "; // JSON형식으로 값을 저장해서 넘기자
		String member = "{ \"name\": \"superman\", \"age\": \"33\", \"phone\": \"010-1234-5678\"}"; // JSON형식으로 값을 저장해서 넘기자
						// {"name": "superman", "age": "33"};
		return member;
	}
	
	@RequestMapping("/jstest/jstest3")
	public String jstest3() {
		return "/jstest/jstest3";
	}
	
	@Autowired
	private MemberMapper mapper;
	
	@RequestMapping("/jstest/getJsonMemberOne")
	public @ResponseBody String getJsonMemberOne() {
		// 한 명의 정보를 데이터베이스에서 읽어와서 전달해주기
		MemberVo mvo=mapper.getMember();
		String member="{ \"name\":\""+mvo.getName()+"\" , \"userid\":\""+mvo.getUserid()+"\" , \"phone\":\""+mvo.getPhone()+"\" }";
		return member;
	}
}

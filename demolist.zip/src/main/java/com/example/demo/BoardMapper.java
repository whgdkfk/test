package com.example.demo;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface BoardMapper {
	@Select("select * from board order by id desc")
	public ArrayList<BoardVo> list();
	
	@Select("select * from board where id=#{param}")
	public BoardVo content(String id);
}


package com.example.demo;

import lombok.Data;

@Data
public class BoardVo { 
	// mydb - board
	private int id,readnum,bimil;
	private String title,name,pwd,content,writeday;
}

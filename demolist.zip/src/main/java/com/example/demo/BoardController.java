package com.example.demo;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BoardController {
	@Autowired
	private BoardMapper mapper;
	
	@RequestMapping("/")
	public String home(Model model) {		
		ArrayList<BoardVo> list = mapper.list();
		model.addAttribute("list", list);
		return "list";
	}
	
	@RequestMapping("/content")
	public String content(String id, Model model) {
		model.addAttribute("bvo", mapper.content(id));
		return "/content";
	}
}

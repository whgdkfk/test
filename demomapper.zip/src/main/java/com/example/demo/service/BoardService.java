package com.example.demo.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.example.demo.vo.BoardVo;

public interface BoardService {
	public String home();
	public String write_ok(BoardVo bvo);
	public String list(Model model, HttpServletRequest request);
	public String readnum(HttpServletRequest request);
	public String content(HttpServletRequest request, Model model);
	public String delete(HttpServletRequest request);
	public String update(HttpServletRequest request, Model model);
	public String update_ok(BoardVo bvo);
}

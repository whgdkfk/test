package com.example.demo.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.example.demo.mapper.BoardMapper;
import com.example.demo.vo.BoardVo;

@Service
@Qualifier("bs")
public class BoardServiceImpl implements BoardService {
	@Autowired
	private BoardMapper mapper;
	
	@Override
	public String home() {
		return "redirect:/list";
	}
	
	@Override
	public String write_ok(BoardVo bvo) {
		mapper.write_ok(bvo);
		return "redirect:/list";
	}
	
	@Override
	public String list(Model model, HttpServletRequest request) {
		int page;
		if (request.getParameter("page") == null)
			page = 1;
		else
			page = Integer.parseInt(request.getParameter("page"));

		// 해당페이지의 start위치를 구하기
		int start = (page - 1) * 10;

		// pstart, pend, chong
		int pstart = page / 10;
		if (page % 10 == 0)
			pstart--;
		pstart = pstart * 10 + 1;

		int pend = pstart + 9;

		// 총페이지보다 pend가 클경우는 총페이지의 값을 pend
		int chong = mapper.getChong();
		// System.out.println(chong);
		if (pend > chong)
			pend = chong;

		model.addAttribute("chong", chong);
		model.addAttribute("pstart", pstart);
		model.addAttribute("pend", pend);
		model.addAttribute("page", page);
		model.addAttribute("list", mapper.list(start));
		return "/list";
	}
	
	@Override
	public String readnum(HttpServletRequest request) {
		String id = request.getParameter("id");
		String page=request.getParameter("page");
		mapper.readnum(id);
		return "redirect:/content?id="+id+"&page="+page;
	}

	@Override
	public String content(HttpServletRequest request, Model model) {
		String id = request.getParameter("id");
		model.addAttribute("bvo", mapper.content(id));
		model.addAttribute("page", request.getParameter("page"));
		return "/content";
	}

	@Override
	public String delete(HttpServletRequest request) {
		String id = request.getParameter("id");
		String page=request.getParameter("page");
		mapper.delete(id);
		return "redirect:/list?page="+page;
	}

	@Override
	public String update(HttpServletRequest request, Model model) {
		String id = request.getParameter("id");
		model.addAttribute("bvo", mapper.content(id));
		model.addAttribute("page", request.getParameter("page"));
		return "/update";
	}

	@Override
	public String update_ok(BoardVo bvo) {
		mapper.update_ok(bvo);
		return "redirect:/content?id="+bvo.getId()+"&page="+bvo.getPage();
	}

	

}

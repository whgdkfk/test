package com.example.demo.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.service.BoardService;
import com.example.demo.vo.BoardVo;

@Controller
public class BoardController {
	
	@Autowired
	@Qualifier("bs")
	private BoardService service;
	
	@RequestMapping("/")
	public String home() {
		return service.home();
	}
	
	@RequestMapping("/write")
	public String write() {
		return "/write";
	}
	
	@RequestMapping("/write_ok")
	public String write_ok(BoardVo bvo) {
		return service.write_ok(bvo);
	}
	
	@RequestMapping("/list")
	public String list(Model model, HttpServletRequest request) {
		return service.list(model, request);
	}
	
	@RequestMapping("/readnum")
	public String readnum(HttpServletRequest request) {
		return service.readnum(request);
	}
	
	@RequestMapping("/content")
	public String content(HttpServletRequest request, Model model) {
		return service.content(request, model);
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request) {
		return service.delete(request);
	}
	
	@RequestMapping("/update")
	public String update(HttpServletRequest request, Model model) {
		return service.update(request, model);
	}
	
	@RequestMapping("/update_ok")
	public String update_ok(BoardVo bvo) {
		return service.update_ok(bvo);
	}
}

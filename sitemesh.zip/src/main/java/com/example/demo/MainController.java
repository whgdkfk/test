package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
    
	 @RequestMapping("/")
	 public String home(){
		 return "/main";
	 }
	 
	 @RequestMapping("/main")
	 public String main(){
		 return "/main";
	 }
	 
	 @RequestMapping("/login/login")
	 public String login(){
		 return "/login/login";
	 }
	 
	 @RequestMapping("/login/my")
	 public String my(){
		 return "/login/my";
	 }
	 
	 @RequestMapping("/login/myjob")
	 public String myjob(){
		 return "/login/myjob";
	 }
}

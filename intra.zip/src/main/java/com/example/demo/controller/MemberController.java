package com.example.demo.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.service.MemberService;
import com.example.demo.vo.MemberVo;

@Controller
public class MemberController {
	@Autowired
	@Qualifier("ms2")
	private MemberService service;
	
	@RequestMapping("/member/login")
	public String login() {
		return service.login();
	}
	
	@RequestMapping("/member/login_ok")
	public String login_ok(MemberVo mvo, HttpSession session) {
		return service.login_ok(mvo, session);
	}
	
	@RequestMapping("/member/member_input")
	public String member_input(Model model){
		return service.member_input(model);
	}
	
	@RequestMapping("/member/member_input_ok")
	public String member_input_ok(MemberVo mvo) {
		return service.member_input_ok(mvo);
	}
	
	@RequestMapping("/member/logout")
	public String logout(HttpSession session) {
		return service.logout(session);
	}
	
	@RequestMapping("/member/mypage")
	public String mypage(Model model, HttpSession session) {
		return service.mypage(model, session);
	}
	
	@RequestMapping("/member/towork")
	public String towork(HttpSession session) {
		return service.towork(session);
	}
	
	@RequestMapping("/member/tohome")
	public String tohome(HttpSession session) {
		return service.tohome(session);
	}
}

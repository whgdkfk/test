package com.example.demo.vo;

import lombok.Data;

@Data // (@Getter, @Setter)
public class MemberVo {
	private int level;
	private String userid,name,pwd,zip,juso,juso_etc,phone,email,ipsa,depart,sawon;
}

package com.example.demo.vo;

import lombok.Data;

@Data
public class CommuteVo {
	private int id;
	private String towork,tohome,writeday,sawon;
}

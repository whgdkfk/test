package com.example.demo.vo;

import lombok.Data;

@Data
public class MemoVo {
	private int id,state;
	private String sesawon,resawon,title,content,writeday;
}

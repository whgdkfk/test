package com.example.demo.vo;

import lombok.Data;

@Data
public class DepartVo {
	private String code,name;
}

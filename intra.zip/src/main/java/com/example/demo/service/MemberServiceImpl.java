package com.example.demo.service;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.example.demo.mapper.MemberMapper;
import com.example.demo.vo.CommuteVo;
import com.example.demo.vo.DepartVo;
import com.example.demo.vo.MemberVo;

@Service
@Qualifier("ms2")
public class MemberServiceImpl implements MemberService {
	@Autowired
	private MemberMapper mapper;

	@Override
	public String login() {
		return "/member/login";
	}

	@Override
	public String login_ok(MemberVo mvo, HttpSession session) {
		MemberVo mvo2 = mapper.login_ok(mvo);
		if(mvo2 != null) { // 아이디와 비밀번호가 일치한다면
			// 세션을 추가
			session.setAttribute("sawon", mvo2.getSawon());
			session.setAttribute("name", mvo2.getName());
			session.setAttribute("level", mvo2.getLevel());
			return "redirect:/main/main";
		}else { // 아이디와 비밀번호가 일치하지 않으면
			return "redirect:/member/login";
		}
	}

	@Override
	public String member_input(Model model) {
		// 부서 정보를 전달
		ArrayList<DepartVo> list = mapper.getDepart();
		model.addAttribute("list", list);
		
		// 사원번호를 mapper를 통해 생성하여 전달
		int num = mapper.getSawon();
		String code = "c" + String.format("%03d", num);
		model.addAttribute("code", code);
		
		return "/member/member_input";
	}

	@Override
	public String member_input_ok(MemberVo mvo) {
		mapper.member_input_ok(mvo);
		return "redirect:/main/main";
	}

	@Override
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/main/main";
	}

	@Override
	public String mypage(Model model, HttpSession session) {
		// 회원정보
		String sawon = session.getAttribute("sawon").toString();
		MemberVo mvo = mapper.getMember(sawon);
		model.addAttribute("mvo", mvo);
		model.addAttribute("depart", mapper.getDepartName(mvo.getDepart()));
		
		// 출퇴근 클릭
		LocalDate today = LocalDate.now();
		CommuteVo cvo = mapper.getCommute(today.toString(), sawon);
		
		int chk;
		if(cvo == null) { // 출근 전
			chk = 1;
		}else if(cvo.getTowork() != null && cvo.getTohome() == null) { // 출근한 상태
			chk = 2;
		}else { // 퇴근한 상태(출퇴근 완료)
			chk = 3;
		}
		
		model.addAttribute("chk", chk);
		
		// 사원 간 쪽지
		
		return "/member/mypage";
	}

	@Override
	public String towork(HttpSession session) {
		String sawon = session.getAttribute("sawon").toString();
		String today = LocalDate.now().toString();
		mapper.towork(today, sawon);
		
		return "redirect:/member/mypage";
	}

	@Override
	public String tohome(HttpSession session) {
		String sawon = session.getAttribute("sawon").toString();
		String today = LocalDate.now().toString();
		mapper.tohome(today, sawon);
		
		return "redirect:/member/mypage";
	}
}

package com.example.demo.service;

public interface MainService {
	public String main();
}

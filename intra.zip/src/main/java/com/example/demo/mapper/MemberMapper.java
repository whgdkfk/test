package com.example.demo.mapper;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.vo.CommuteVo;
import com.example.demo.vo.DepartVo;
import com.example.demo.vo.MemberVo;

@Mapper
public interface MemberMapper {
	public MemberVo login_ok(MemberVo mvo);
	public ArrayList<DepartVo> getDepart();
	public int getSawon();
	public void member_input_ok(MemberVo mvo);
	public MemberVo getMember(String sawon);
	public String getDepartName(String depart);
	public CommuteVo getCommute(String today, String sawon);
	public void towork(String today, String sawon);
	public void tohome(String today, String sawon);
}

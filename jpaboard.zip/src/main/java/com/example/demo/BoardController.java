package com.example.demo;

import java.time.LocalDate;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BoardController {
	@Autowired
	private BoardRepository repo;
	
	@RequestMapping("/")
	public String home() {
		return "redirect:/list";
	}
	
	@RequestMapping("/list")
	public String list(Model model) {
		// DB에서 값을 읽어오기
		model.addAttribute("list", repo.list());
		return "/list";
	}
	
	@RequestMapping("/content")
	public String content(HttpServletRequest request, Model model) {
		int id = Integer.parseInt(request.getParameter("id"));
		Board bvo = repo.content(id);
		bvo.setContent(bvo.getContent().replace("\r\n", "<br>"));
		model.addAttribute("bvo", bvo);
		
		return "/content";
	}
	
	@RequestMapping("/update")
	public String update(int id, Model model) {
		Board bvo = repo.content(id);
		model.addAttribute("bvo", bvo);
		return "/update";
	}
	
	@RequestMapping("/update_ok")
	public String update_ok(Board bvo) {
		repo.update(bvo);
		return "redirect:/content?id="+bvo.getId();
	}
	
	@RequestMapping("/delete")
	public String delete(int id) {
		repo.delete(id);
		return "redirect:/list";
	}
	
	@RequestMapping("/write")
	public String write() {
		return "/write";
	}
	
	@RequestMapping("/write_ok")
	public String write_ok(Board bvo) {
		bvo.setWriteday(LocalDate.now().toString());
		repo.write_ok(bvo);
		return "redirect:/list";
	}
	
	@RequestMapping("/readnum")
	public String readnum(int id) {
		// readnum 필드의 값을 1 증가
		repo.updateReadnum(id);
		return "redirect:/content?id="+id;
	}

}

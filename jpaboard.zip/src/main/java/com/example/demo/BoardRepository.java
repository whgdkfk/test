package com.example.demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class BoardRepository {
	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private BoardRepository2 repo2;
	
	public List<Board> list(){
		String sql = "select b from Board b order by id desc"; // Entity 클래스 이름
		TypedQuery<Board> list = manager.createQuery(sql, Board.class);
		
		return list.getResultList();
	}
	
	public Board content(int id) {
		return manager.find(Board.class, id);
	}
	
	@Transactional
	public Board update(Board bvo) {
		Board bvo2 = manager.find(Board.class, bvo.getId()); // 기존 레코드값
		
		bvo.setWriteday(bvo2.getWriteday());
		bvo.setReadnum(bvo2.getReadnum());
		bvo.setPwd(bvo2.getPwd());
		
		return manager.merge(bvo);
	}
	
	 @Transactional
	 public void delete(int id) {
		 Board bvo = manager.find(Board.class, id);
		 manager.remove(bvo);
	 }
	 
	 @Transactional
	 public void write_ok(Board bvo) {
		 manager.persist(bvo);
	 }
	 
	 @Transactional
	 public void updateReadnum(int id) {
		 repo2.updateReadnum(id);
	 }
}

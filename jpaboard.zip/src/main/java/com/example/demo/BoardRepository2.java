package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface BoardRepository2 extends JpaRepository<Board, Integer>{
	@Modifying
	@Query("update Board b set b.readnum=b.readnum+1 where b.id=:id")
	void updateReadnum(int id);
}

package com.example.demo.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.service.ThboardService;
import com.example.demo.vo.ThboardVo;

@Controller
public class ThboardController {
    
	@Autowired
	@Qualifier("ts")
	private ThboardService service;
	
	@RequestMapping("/")
	public String home(){
		return "redirect:/list";
	}
	
	@RequestMapping("/list")
	public String list(Model model, HttpServletRequest request){
		return service.list(model, request);
	}
	
	@RequestMapping("/each")
	public String each(Model model){
		// 집합형태의 데이터를 view에 전달
		ArrayList<String> list=new ArrayList<String>();
		list.add("탕수육");
		list.add("팔보채");
		list.add("양장피");
		list.add("전가복");

		model.addAttribute("list",list);
		return "/each";
	}
	
	@RequestMapping("/if")
	public String if2(Model model){
		// 1이면 합격  2이면 불합격
		model.addAttribute("chk", "1");
		model.addAttribute("num", 1);
		
		return "/if";
	}
	
	@RequestMapping("/switch")
	public String switch2(Model model){
		// 1:광어초밥 2:연어초밥 3:학공치초밥 4:벵에돔초밥 나머지는 아무초밥
		model.addAttribute("sel", 2);
		return "/switch";
	}
	
	@RequestMapping("/readnum")
	public String readnum(HttpServletRequest request) {
		return service.readnum(request);
	}
	
	@RequestMapping("/content")
	public String content(Model model, HttpServletRequest request) {
		return service.content(model, request);
	}
	
	@RequestMapping("/write")
	public String write() {
		return service.write();
	}
	
	@RequestMapping("/write_ok")
	public String write_ok(ThboardVo bvo) {
		return service.write_ok(bvo);
	}
	
	@RequestMapping("/update")
	public String update(Model model, ThboardVo bvo) {
		return service.update(model, bvo);
	}
	
	@RequestMapping("/update_ok")
	public String update_ok(ThboardVo bvo) {
		return service.update_ok(bvo);
	}
	
	@RequestMapping("/delete")
	public String delete(ThboardVo bvo) {
		return service.delete(bvo);
	}
}

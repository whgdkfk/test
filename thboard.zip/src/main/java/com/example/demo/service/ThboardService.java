package com.example.demo.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

public interface ThboardService {
    public String list(Model model, HttpServletRequest request);
}

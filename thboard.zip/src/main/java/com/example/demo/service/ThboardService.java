package com.example.demo.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.example.demo.vo.ThboardVo;

public interface ThboardService {
    public String list(Model model, HttpServletRequest request);
    public String readnum(HttpServletRequest request);
    public String content(Model model, HttpServletRequest request);
    public String write();
    public String write_ok(ThboardVo bvo);
    public String update(Model model, ThboardVo bvo);
    public String update_ok(ThboardVo bvo);
    public String delete(ThboardVo bvo);
}

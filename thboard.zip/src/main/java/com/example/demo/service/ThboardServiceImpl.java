package com.example.demo.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.example.demo.mapper.ThboardMapper;
import com.example.demo.vo.ThboardVo;

@Service
@Qualifier("ts")
public class ThboardServiceImpl implements ThboardService{

	@Autowired
	private ThboardMapper mapper;

	@Override
	public String list(Model model,HttpServletRequest request) {
		
		 // 페이지의 시작인덱스, pstart, pend, chong
		 int page;
		 if(request.getParameter("page")==null)
			page=1;
		 else
		    page=Integer.parseInt(request.getParameter("page"));
		 
		 // 해당페이지의 start위치를 구하기
		 int index=(page-1)*10;
		 
		 // pstart, pend, chong
		 int pstart=page/10;
		 if(page%10 == 0)
			 pstart--;
		 pstart=pstart*10+1;
		 
		 int pend=pstart+9;
		 
		 int chong=mapper.getChong();
		 
		 if(pend>chong)
			 pend=chong;
		 
		 model.addAttribute("pstart",pstart);
		 model.addAttribute("pend",pend);
		 model.addAttribute("page",page);
		 model.addAttribute("chong",chong);
		ArrayList<ThboardVo> list=mapper.list(index);
		
		model.addAttribute("list",list);
		
		return "/list";
	}

	@Override
	public String readnum(HttpServletRequest request) {
		String id = request.getParameter("id");
		String page = request.getParameter("page");
		// readnum필드의 값 1 증가
		mapper.readnum(id);
		// content로 이동
		return "redirect:/content?id="+id+"&page="+page;
	}

	@Override
	public String content(Model model, HttpServletRequest request) {
		String id = request.getParameter("id");
		String page = request.getParameter("page");
		
		int chk;
		if(request.getParameter("chk") != null)
			chk = Integer.parseInt(request.getParameter("chk"));
		else
			chk = 0;
		
		// 하나의 레코드 읽기
		ThboardVo bvo = mapper.content(id);
		bvo.setContent(bvo.getContent().replace("\r\n", "<br>"));
		// bvo.setPage(Integer.parseInt(page));
		bvo.setChk(chk);
		
		// model을 통해 view에 전달
		model.addAttribute("bvo", bvo);
		model.addAttribute("page", page);
		model.addAttribute("chk", 1);
		
		// view 전달
		return "/content";
	}

	@Override
	public String write() {
		return "/write";
	}

	@Override
	public String write_ok(ThboardVo bvo) {
		mapper.write_ok(bvo);
		return "redirect:/list";
	}

	@Override
	public String update(Model model, ThboardVo bvo) {
		ThboardVo bvo2 = mapper.content(bvo.getId()+"");
		bvo2.setPage(bvo.getPage());
		bvo2.setChk(bvo.getChk());
		// model.addAttribute("page", bvo.getPage());
		model.addAttribute("bvo", bvo2);
		return "/update";
	}

	@Override
	public String update_ok(ThboardVo bvo) {
		int chk = mapper.isPwd(bvo.getId(), bvo.getPwd());
		
		// 비밀번호가 맞다면
		if(chk==1) {
			mapper.update_ok(bvo);
		    return "redirect:/content?id="+bvo.getId()+"&page="+bvo.getPage();
		}else {
			return "redirect:/update?chk=1&id="+bvo.getId()+"&page="+bvo.getPage();
		}
	}

	@Override
	public String delete(ThboardVo bvo) {
		int chk = mapper.isPwd(bvo.getId(), bvo.getPwd());
		
		// 비밀번호가 맞다면
		if(chk == 1) {
			mapper.delete(bvo.getId());
			return "redirect:/list?page="+bvo.getPage();
		}else {
			return "redirect:/content?chk=1&id="+bvo.getId()+"&page="+bvo.getPage();
		}
	}
}
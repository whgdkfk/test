package com.example.demo.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.example.demo.mapper.ThboardMapper;
import com.example.demo.vo.ThboardVo;

@Service
@Qualifier("ts")
public class ThboardServiceImpl implements ThboardService{

	@Autowired
	private ThboardMapper mapper;

	@Override
	public String list(Model model,HttpServletRequest request) {
		
		 // 페이지의 시작인덱스, pstart, pend, chong
		 int page;
		 if(request.getParameter("page")==null)
			page=1;
		 else
		    page=Integer.parseInt(request.getParameter("page"));
		 
		 // 해당페이지의 start위치를 구하기
		 int index=(page-1)*10;
		 
		 // pstart, pend, chong
		 int pstart=page/10;
		 if(page%10 == 0)
			 pstart--;
		 pstart=pstart*10+1;
		 
		 int pend=pstart+9;
		 
		 int chong=mapper.getChong();
		 
		 if(pend>chong)
			 pend=chong;
		 
		 model.addAttribute("pstart",pstart);
		 model.addAttribute("pend",pend);
		 model.addAttribute("page",page);
		 model.addAttribute("chong",chong);
		ArrayList<ThboardVo> list=mapper.list(index);
		
		model.addAttribute("list",list);
		
		return "/list";
	}
}
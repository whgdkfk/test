package com.example.demo.vo;

import lombok.Data;

@Data
public class ThboardVo {
	private int id,readnum,bimil;
	private String title,name,pwd,content,writeday;
}

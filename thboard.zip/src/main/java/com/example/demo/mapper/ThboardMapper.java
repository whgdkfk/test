package com.example.demo.mapper;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.demo.vo.ThboardVo;

@Mapper
public interface ThboardMapper {
	public ArrayList<ThboardVo> list(@Param("index") int index);
	public int getChong();
	public void readnum(String id);
	public ThboardVo content(String id);
	public void write_ok(ThboardVo bvo);
	public int isPwd(int id, String pwd);
	public void update_ok(ThboardVo bvo);
	public void delete(int id);
}

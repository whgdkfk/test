package com.example.demo.mapper;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.demo.vo.ThboardVo;

@Mapper
public interface ThboardMapper {
	public ArrayList<ThboardVo> list(@Param("index") int index);
	public int getChong();
}
